const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');
let form = express();
form.use(bodyParser.urlencoded({ extended: false }));
form.set('views', path.join(__dirname, 'views'));
form.set('view engine', 'ejs');
form.get('/', function (req, res) {
  res.render('form');
});

let emailRegex = /\w+@\w+.\w+/;
let phoneRegex = /^\d{3}-*\d{3}-*\d{4}$/;
function regexValidation(input, regex) {
  if (regex.test(input)) {
    return true;
  }else {
    return false;
  }
}

function customEmailValidation(value) {
  if (!regexValidation(value, emailRegex)) {
    throw new Error('Emial address must be valid.');
  }

  return true;
}

function customPhoneValidation(value) {
  if (!regexValidation(value, phoneRegex)) {
    throw new Error('Phone should be in the format xxx-xxx-xxxx.');
  }

  return true;
}

form.post('/', [
  check('name', 'Name cannot be empty.').not().isEmpty(),
  check('email').custom(customEmailValidation),
  check('phone').custom(customPhoneValidation),
  check('province', 'Province cannot be empty.').not().isEmpty(),
  check('address', 'Address cannot be empty.').not().isEmpty()
], function (req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.render('form', { errors: errors.array() });
  }else {
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let province = req.body.province;
    let address = req.body.address;
    let receipt = {
      name: name,
      email: email,
      phone: phone,
      province: province,
      address: address,
    };
    res.render('form', receipt);
  }
});

form.listen(3000, () => {
  console.log('On port 3000.');
});
