﻿namespace EncounterNotes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpbxModifyNotes = new System.Windows.Forms.GroupBox();
            this.listBoxMesurements = new System.Windows.Forms.ListBox();
            this.listBoxProblems = new System.Windows.Forms.ListBox();
            this.btnDeleteNote = new System.Windows.Forms.Button();
            this.btnUpdateNote = new System.Windows.Forms.Button();
            this.btnAddNote = new System.Windows.Forms.Button();
            this.dateTimePickerBirth = new System.Windows.Forms.DateTimePicker();
            this.btnAddProblem = new System.Windows.Forms.Button();
            this.txtNewProblem = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rtxtNotes = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNewNote = new System.Windows.Forms.Button();
            this.lblErrMsg = new System.Windows.Forms.Label();
            this.listBoxEncounterNotes = new System.Windows.Forms.ListBox();
            this.gpbxModifyNotes.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbxModifyNotes
            // 
            this.gpbxModifyNotes.Controls.Add(this.listBoxMesurements);
            this.gpbxModifyNotes.Controls.Add(this.listBoxProblems);
            this.gpbxModifyNotes.Controls.Add(this.btnDeleteNote);
            this.gpbxModifyNotes.Controls.Add(this.btnUpdateNote);
            this.gpbxModifyNotes.Controls.Add(this.btnAddNote);
            this.gpbxModifyNotes.Controls.Add(this.dateTimePickerBirth);
            this.gpbxModifyNotes.Controls.Add(this.btnAddProblem);
            this.gpbxModifyNotes.Controls.Add(this.txtNewProblem);
            this.gpbxModifyNotes.Controls.Add(this.txtName);
            this.gpbxModifyNotes.Controls.Add(this.label7);
            this.gpbxModifyNotes.Controls.Add(this.txtID);
            this.gpbxModifyNotes.Controls.Add(this.label6);
            this.gpbxModifyNotes.Controls.Add(this.rtxtNotes);
            this.gpbxModifyNotes.Controls.Add(this.label5);
            this.gpbxModifyNotes.Controls.Add(this.label4);
            this.gpbxModifyNotes.Controls.Add(this.label3);
            this.gpbxModifyNotes.Controls.Add(this.label2);
            this.gpbxModifyNotes.Controls.Add(this.label1);
            this.gpbxModifyNotes.Location = new System.Drawing.Point(369, 26);
            this.gpbxModifyNotes.Name = "gpbxModifyNotes";
            this.gpbxModifyNotes.Size = new System.Drawing.Size(1172, 738);
            this.gpbxModifyNotes.TabIndex = 0;
            this.gpbxModifyNotes.TabStop = false;
            this.gpbxModifyNotes.Text = "Add/Edit/Delete Encounter Notes:";
            // 
            // listBoxMesurements
            // 
            this.listBoxMesurements.FormattingEnabled = true;
            this.listBoxMesurements.ItemHeight = 32;
            this.listBoxMesurements.Location = new System.Drawing.Point(950, 92);
            this.listBoxMesurements.Name = "listBoxMesurements";
            this.listBoxMesurements.Size = new System.Drawing.Size(178, 228);
            this.listBoxMesurements.TabIndex = 17;
            // 
            // listBoxProblems
            // 
            this.listBoxProblems.FormattingEnabled = true;
            this.listBoxProblems.ItemHeight = 32;
            this.listBoxProblems.Location = new System.Drawing.Point(708, 92);
            this.listBoxProblems.Name = "listBoxProblems";
            this.listBoxProblems.Size = new System.Drawing.Size(178, 228);
            this.listBoxProblems.TabIndex = 16;
            // 
            // btnDeleteNote
            // 
            this.btnDeleteNote.Location = new System.Drawing.Point(419, 674);
            this.btnDeleteNote.Name = "btnDeleteNote";
            this.btnDeleteNote.Size = new System.Drawing.Size(150, 47);
            this.btnDeleteNote.TabIndex = 15;
            this.btnDeleteNote.Text = "Delete note";
            this.btnDeleteNote.UseVisualStyleBackColor = true;
            this.btnDeleteNote.Click += new System.EventHandler(this.btnDeleteNote_Click);
            // 
            // btnUpdateNote
            // 
            this.btnUpdateNote.Location = new System.Drawing.Point(228, 674);
            this.btnUpdateNote.Name = "btnUpdateNote";
            this.btnUpdateNote.Size = new System.Drawing.Size(165, 47);
            this.btnUpdateNote.TabIndex = 14;
            this.btnUpdateNote.Text = "Update note";
            this.btnUpdateNote.UseVisualStyleBackColor = true;
            this.btnUpdateNote.Click += new System.EventHandler(this.btnUpdateNote_Click);
            // 
            // btnAddNote
            // 
            this.btnAddNote.Location = new System.Drawing.Point(44, 674);
            this.btnAddNote.Name = "btnAddNote";
            this.btnAddNote.Size = new System.Drawing.Size(150, 47);
            this.btnAddNote.TabIndex = 13;
            this.btnAddNote.Text = "Add note";
            this.btnAddNote.UseVisualStyleBackColor = true;
            this.btnAddNote.Click += new System.EventHandler(this.btnAddNote_Click);
            // 
            // dateTimePickerBirth
            // 
            this.dateTimePickerBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerBirth.Location = new System.Drawing.Point(213, 198);
            this.dateTimePickerBirth.Name = "dateTimePickerBirth";
            this.dateTimePickerBirth.Size = new System.Drawing.Size(356, 39);
            this.dateTimePickerBirth.TabIndex = 12;
            this.dateTimePickerBirth.Value = new System.DateTime(2022, 3, 21, 18, 34, 17, 0);
            // 
            // btnAddProblem
            // 
            this.btnAddProblem.Location = new System.Drawing.Point(533, 269);
            this.btnAddProblem.Name = "btnAddProblem";
            this.btnAddProblem.Size = new System.Drawing.Size(125, 37);
            this.btnAddProblem.TabIndex = 11;
            this.btnAddProblem.Text = "Add";
            this.btnAddProblem.UseVisualStyleBackColor = true;
            this.btnAddProblem.Click += new System.EventHandler(this.btnAddProblem_Click);
            // 
            // txtNewProblem
            // 
            this.txtNewProblem.Location = new System.Drawing.Point(213, 266);
            this.txtNewProblem.Name = "txtNewProblem";
            this.txtNewProblem.Size = new System.Drawing.Size(293, 39);
            this.txtNewProblem.TabIndex = 10;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(213, 129);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(356, 39);
            this.txtName.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(939, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(199, 32);
            this.label7.TabIndex = 8;
            this.label7.Text = "BP Mesurements:";
            // 
            // txtID
            // 
            this.txtID.Enabled = false;
            this.txtID.Location = new System.Drawing.Point(152, 60);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(253, 39);
            this.txtID.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(701, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 32);
            this.label6.TabIndex = 6;
            this.label6.Text = "Problems:";
            // 
            // rtxtNotes
            // 
            this.rtxtNotes.Location = new System.Drawing.Point(44, 376);
            this.rtxtNotes.Name = "rtxtNotes";
            this.rtxtNotes.Size = new System.Drawing.Size(1084, 257);
            this.rtxtNotes.TabIndex = 5;
            this.rtxtNotes.Text = "";
            this.rtxtNotes.TextChanged += new System.EventHandler(this.rtxtNotes_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 331);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "Notes:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 269);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "New Problem:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date of Birth:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Patient Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Note ID:";
            // 
            // btnNewNote
            // 
            this.btnNewNote.Location = new System.Drawing.Point(54, 26);
            this.btnNewNote.Name = "btnNewNote";
            this.btnNewNote.Size = new System.Drawing.Size(196, 40);
            this.btnNewNote.TabIndex = 1;
            this.btnNewNote.Text = "Start new note";
            this.btnNewNote.UseVisualStyleBackColor = true;
            this.btnNewNote.Click += new System.EventHandler(this.btnNewNote_Click);
            // 
            // lblErrMsg
            // 
            this.lblErrMsg.AutoSize = true;
            this.lblErrMsg.Location = new System.Drawing.Point(54, 792);
            this.lblErrMsg.Name = "lblErrMsg";
            this.lblErrMsg.Size = new System.Drawing.Size(88, 32);
            this.lblErrMsg.TabIndex = 3;
            this.lblErrMsg.Text = "ErrMsg";
            // 
            // listBoxEncounterNotes
            // 
            this.listBoxEncounterNotes.FormattingEnabled = true;
            this.listBoxEncounterNotes.ItemHeight = 32;
            this.listBoxEncounterNotes.Location = new System.Drawing.Point(54, 93);
            this.listBoxEncounterNotes.Name = "listBoxEncounterNotes";
            this.listBoxEncounterNotes.Size = new System.Drawing.Size(278, 676);
            this.listBoxEncounterNotes.TabIndex = 4;
            this.listBoxEncounterNotes.SelectedIndexChanged += new System.EventHandler(this.listBoxEncounterNotes_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1589, 855);
            this.Controls.Add(this.listBoxEncounterNotes);
            this.Controls.Add(this.lblErrMsg);
            this.Controls.Add(this.btnNewNote);
            this.Controls.Add(this.gpbxModifyNotes);
            this.Name = "Form1";
            this.Text = "Encounter Notes";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gpbxModifyNotes.ResumeLayout(false);
            this.gpbxModifyNotes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox gpbxModifyNotes;
        private Button btnAddNote;
        private DateTimePicker dateTimePickerBirth;
        private Button btnAddProblem;
        private TextBox txtNewProblem;
        private TextBox txtName;
        private Label label7;
        private TextBox txtID;
        private Label label6;
        private RichTextBox rtxtNotes;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnNewNote;
        private Label lblErrMsg;
        private Button btnDeleteNote;
        private Button btnUpdateNote;
        private ListBox listBoxEncounterNotes;
        private ListBox listBoxMesurements;
        private ListBox listBoxProblems;
    }
}