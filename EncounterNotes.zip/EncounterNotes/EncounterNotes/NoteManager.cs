﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncounterNotes
{
    public class NoteManager
    {
        private const string _filePath = @"EncounterNotes.txt";
        private static List<Note> _notes = new List<Note>();
        public static List<Note> GetNotes()
        {
            return _notes;
        }
        public static Note GetNoteById(int noteId)
        { 
            return _notes.FirstOrDefault(n => n.NoteId == noteId);
        }
        public static void ReadNotesFromFile()
        {
            _notes.Clear();
            using (StreamReader streamReader = new StreamReader(_filePath))
            {
                while (!streamReader.EndOfStream)
                {
                    string? noteRecord = streamReader.ReadLine();
                    if (noteRecord != null)
                    {
                        string[] noteFields = noteRecord.Split('|');
                        Note note = new Note();
                        note.NoteId = int.Parse(noteFields[0]);
                        note.PatientName = noteFields[1];
                        note.DateOfBirth = DateTime.Parse(noteFields[2]);
                        if (noteFields.Length == 5)
                        {
                            string[] newProblems = noteFields[3].Split("; ");
                            note.NewProblems = newProblems.ToList();
                            //foreach (string problem in newProblems)
                            //{
                            //    note.NewProblems.Add(problem);
                            //}
                            note.Notes = noteFields[4].Replace(";", "\n");
                        }
                        else
                        {
                            note.Notes = noteFields[3];
                        }
                        _notes.Add(note);
                    }
                }
            }
        }
        public static void LoadFile()
        {
            if (!File.Exists(_filePath))
            {
                File.Create(_filePath).Dispose();
            }
            ReadNotesFromFile();
        }
        private static string WriteNoteToRecord(Note note)
        {
            string? problems;     //?

            if (note.NewProblems == null)
            {
                return note.NoteId.ToString() + "|" + note.PatientName + "|" +
                    note.DateOfBirth.ToString() + "|" + note.Notes.Replace("\n", ";");
            }
            else
            {
                //foreach (string item in note.NewProblems)
                //{
                //    problems += item + "; ";
                //}

                problems = String.Join("; ", note.NewProblems);

                return note.NoteId.ToString() + "|" + note.PatientName + "|" +
                    note.DateOfBirth.ToString() + "|" + problems + "|" + note.Notes.Replace("\n", ";");
            }
        }
        public static void WriteRecordToFile()
        {
            using (StreamWriter streamWriter = new StreamWriter(_filePath))
            {
                foreach (Note note in _notes)
                {
                    streamWriter.WriteLine(WriteNoteToRecord(note));
                }
            }
        }
        public static int GetNextNoteId()
        {
            if (_notes.Count() == 0)
            {
                return 1;
            }
            else
            {
                return _notes.Max(n => n.NoteId) + 1; 
            }
        }
        public static void DeleteRecordById(int noteId)
        {
            _notes.RemoveAll(n => n.NoteId == noteId);
            WriteRecordToFile();
        }
    }
}
