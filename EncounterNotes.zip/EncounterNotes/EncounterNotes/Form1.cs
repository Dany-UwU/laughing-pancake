using System.Text.RegularExpressions;
namespace EncounterNotes
{
    public partial class Form1 : Form
    {
        private List<string>? _newProblems = new List<string>();
        private Regex _bpReadingPattern = new Regex(@"(BP:?) (\d{2,3}/\d{2,3})", RegexOptions.IgnoreCase);
        private void ResetTexts()
        {
            foreach (TextBox textBox in gpbxModifyNotes.Controls.OfType<TextBox>())
            {
                textBox.Text = string.Empty;
            }
            foreach (RichTextBox richTextBox in gpbxModifyNotes.Controls.OfType<RichTextBox>())
            {
                richTextBox.Text = string.Empty;
            }
            foreach (ListBox listBox in gpbxModifyNotes.Controls.OfType<ListBox>())
            {
                listBox.Items.Clear();
            }
            // Clears the problems from the last selected note
            _newProblems.Clear();
        }
        private void AwaitingMode()
        {
            ResetTexts();
            gpbxModifyNotes.Enabled = false;
            listBoxEncounterNotes.SelectedIndex = -1;
        }
        private void IsAddMode(bool mode)
        {
            ResetTexts();
            gpbxModifyNotes.Enabled = true;
            btnAddNote.Enabled = mode;
            btnUpdateNote.Enabled = !mode;
            btnDeleteNote.Enabled = !mode;
        }
        public void ModifyNote()
        {
            lblErrMsg.Text = string.Empty;
            try
            {
                Note _note = new Note();
                _note.NoteId = NoteManager.GetNextNoteId();
                _note.PatientName = txtName.Text.Trim();
                _note.DateOfBirth = dateTimePickerBirth.Value;
                if (_newProblems != null)
                {
                    _note.NewProblems = _newProblems.ToList();
                }
                _note.Notes = rtxtNotes.Text.Trim();
                NoteManager.GetNotes().Add(_note);
                lblErrMsg.Text = "Note saved.";
                NoteManager.WriteRecordToFile();
                LoadNotesList();
                AwaitingMode();
            }
            catch (ArgumentNullException)
            {
                lblErrMsg.Text = "Patient Name and Notes are required.\n";
            }
            catch (ArgumentOutOfRangeException)
            {
                lblErrMsg.Text += "Date of Birth cannot be in the future.";
            }
            catch (Exception)
            {
                lblErrMsg.Text += "Oops.";
            }
        }
        public void UpdateNote()
        {
            lblErrMsg.Text = string.Empty;
            try
            {
                Note _note = (Note)listBoxEncounterNotes.SelectedItem;
                int id  = _note.NoteId;
                _note = NoteManager.GetNoteById(id);
                _note.PatientName = txtName.Text.Trim();
                _note.DateOfBirth = dateTimePickerBirth.Value;
                if (_newProblems != null)
                {
                    _note.NewProblems = _newProblems.ToList();
                }
                _note.Notes = rtxtNotes.Text.Trim();
                lblErrMsg.Text = "Note updated.";
                NoteManager.WriteRecordToFile();
                LoadNotesList();
                AwaitingMode();
            }
            catch (ArgumentNullException)
            {
                lblErrMsg.Text = "Patient Name and Notes are required.\n";
            }
            catch (ArgumentOutOfRangeException)
            {
                lblErrMsg.Text += "Date of Birth cannot be in the future.";
            }
            catch (Exception)
            {
                lblErrMsg.Text += "Oops.";
            }
        }
        private void LoadNotesList()
        {
            listBoxEncounterNotes.Items.Clear();
            List<Note> notes = NoteManager.GetNotes();
            foreach (Note note in notes)
            {
                listBoxEncounterNotes.Items.Add(note);
            }
        }
        private void LoadProblemsList(Note selectedNote)
        {
            //listBoxProblems.Items.Clear();
            if (selectedNote.NewProblems != null)
            {
                //_newProblems = selectedNote.NewProblems;

                _newProblems.Clear();
                _newProblems.AddRange(selectedNote.NewProblems);

                foreach (string problem in _newProblems)
                {
                    listBoxProblems.Items.Add(problem);
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblErrMsg.Text = string.Empty;
            AwaitingMode();
            NoteManager.LoadFile();
            LoadNotesList();
        }

        private void btnNewNote_Click(object sender, EventArgs e)
        {
            lblErrMsg.Text = string.Empty;
            IsAddMode(true);
            txtID.Text = NoteManager.GetNextNoteId().ToString();
        }

        private void btnAddProblem_Click(object sender, EventArgs e)
        {
            _newProblems.Add(txtNewProblem.Text);
            listBoxProblems.Items.Clear();
            if (_newProblems != null)
            {
                foreach (string problem in _newProblems)
                {
                    listBoxProblems.Items.Add(problem);
                }
            }
            txtNewProblem.Text = string.Empty;
        }

        private void btnAddNote_Click(object sender, EventArgs e)
        {
            ModifyNote();
            _newProblems.Clear(); //
        }

        private void listBoxEncounterNotes_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblErrMsg.Text = string.Empty;
            int index = listBoxEncounterNotes.SelectedIndex;
            if (index != -1)
            {
                IsAddMode(false);
                Note selectedNote = (Note)listBoxEncounterNotes.SelectedItem;
                txtID.Text = selectedNote.NoteId.ToString();
                txtName.Text = selectedNote.PatientName.ToString();
                LoadProblemsList(selectedNote);
                rtxtNotes.Text = selectedNote.Notes;
            }
        }

        private void btnUpdateNote_Click(object sender, EventArgs e)
        {
            UpdateNote();
        }

        private void rtxtNotes_TextChanged(object sender, EventArgs e)
        {
            string noteContent = rtxtNotes.Text.Trim();
            if (!string.IsNullOrWhiteSpace(noteContent))
            {
                listBoxMesurements.Items.Clear();

                MatchCollection matches = _bpReadingPattern.Matches(noteContent);
                foreach (Match match in matches)
                {
                    if (match.Success)
                    {
                        listBoxMesurements.Items.Add(match.Groups[2].Value);
                    }
                }
            }

        }

        private void btnDeleteNote_Click(object sender, EventArgs e)
        {
            int index = listBoxEncounterNotes.SelectedIndex;
            Note note = (Note)listBoxEncounterNotes.SelectedItem;
            if (index != -1)
            {
                NoteManager.DeleteRecordById(note.NoteId);
            }
            LoadNotesList();
            lblErrMsg.Text = "Note deleted.";
            AwaitingMode();
        }
    }
}