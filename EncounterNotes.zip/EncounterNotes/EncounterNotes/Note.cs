﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncounterNotes
{
    public class Note
    {
        public int NoteId { get; set; }
        private string _patientName;
        public string PatientName
        {
            get { return _patientName; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException();
                }
                _patientName = value;
            }
        }
        private DateTime _dateOfBirth;
        public DateTime DateOfBirth
        {
            get { return _dateOfBirth; }
            set
            {
                if (value > DateTime.Now)
                {
                    throw new ArgumentOutOfRangeException();
                }
                 _dateOfBirth = value;
            }
        }
        public List<string>? NewProblems;
        private string _notes;
        public string Notes
        {
            get { return _notes; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException();
                }
                _notes = value;
            }
        }
        public override string ToString()
        {
            return $"{PatientName} (Note: {NoteId})";
        }
    }
}
